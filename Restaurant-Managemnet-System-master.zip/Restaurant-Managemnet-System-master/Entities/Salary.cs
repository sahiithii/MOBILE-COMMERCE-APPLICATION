﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
   public class Salary
    {
       public int Eid{ get; set; }
        public string  Name{ get; set; }
         public string Month{ get; set; }
         public double Pay{ get; set; }
         public double Total_Salary{ get; set; }
         public double Remain_salary { get; set; }
         public string Year { get; set; }

    }
}
