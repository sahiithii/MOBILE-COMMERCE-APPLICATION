# Restaurant Managemnet System
<p align= "center" > <b> This is a 5-Tier Architecture application. </b> </p>

## User
The system has two user 
1. Admin 
2. Staff

## Features 
* Reports
  * Sales Report
  * Purchase Report
  * Expense Report
  * Salary Report
* POS System
* Inventory
* Add Special Customers
* Register New Staffs
